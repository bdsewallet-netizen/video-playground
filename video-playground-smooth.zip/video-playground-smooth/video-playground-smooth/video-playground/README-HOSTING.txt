VIDEO PLAYGROUND - HOSTING SETUP (InfinityFree or any PHP hosting)
===================================================================

1) EDIT api.php (open it in a text editor) and change this line to YOUR secret PIN:
       const ADMIN_PIN = 'CHANGE_ME';
   This is the PIN you will type in the Admin Portal. Saving is blocked until you change it.

2) Upload EVERYTHING in this folder into the "htdocs" folder of your hosting:
       htdocs/
         index.html
         api.php          <- saves your ads + videos on the server
         share.php        <- gives each shared video its own preview card
         og-image.php     <- picture used when a video has no thumbnail
         css/  js/
         data/            <- must be writable (site-data.json is created here)
         thumbs/          <- must be writable (captured thumbnails go here)
   (If saving fails with "not writable", set the data and thumbs folders to permission 755 or 777
    in your hosting file manager.)

3) Open your site, go to Admin Portal, type your PIN. The badge at the top must say
   "Saved on server: live for all visitors". Ads, videos and thumbnails now stay after every deploy.

4) Sharing: the Share button gives a link like  https://your-site/share.php?v=12
   Social apps read that page to show the video's thumbnail + title.
   Tip: in Edit Video press "Capture from video" so each video has a real thumbnail.
   Facebook / WhatsApp keep the old preview cached: use the Facebook Sharing Debugger to refresh it.

Notes
 - Videos must be a hosted URL (or a file uploaded to your hosting, e.g. videos/a.mp4).
   A file picked with "Browse PC" lives only in the admin's browser, so other people cannot see it.
 - Do not delete data/site-data.json: it holds your ads and video list. Download a copy now and then.
